/*
 * The contents of this file are subject to the license and copyright
 * detailed in the LICENSE and NOTICE files at the root of the source
 * tree and available online at
 *
 * http://www.dspace.org/license/
 */
$(function() {

    $("#aspect_administrative_item_AddBitstreamForm_field_embargo_until_date").datepicker({dateFormat: 'yy-mm-dd'});
    $("#aspect_administrative_item_EditBitstreamForm_field_embargo_until_date").datepicker({dateFormat: 'yy-mm-dd'});

    $("#aspect_administrative_item_AddBitstreamForm_field_embargo_until_date").datepicker();

    $("#aspect_administrative_item_EditBitstreamForm_field_embargo_until_date").datepicker();
});
